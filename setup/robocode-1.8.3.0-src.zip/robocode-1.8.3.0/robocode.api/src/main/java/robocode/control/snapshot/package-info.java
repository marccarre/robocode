/**
 * Snapshots of the battle turns, robots, bullets, scores etc.
 */
package robocode.control.snapshot;
