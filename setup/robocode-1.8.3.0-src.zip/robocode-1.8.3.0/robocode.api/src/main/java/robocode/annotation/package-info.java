/**
 * Contains annotations that can be used with Robocode.
 */
package robocode.annotation;
